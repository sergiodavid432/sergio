<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario de Inicio de Sesión y Registro</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 100%;
        }
        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }
        input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
        .change-password-link,
        .register-link {
            text-decoration: none;
            color: #007bff;
            margin-top: 10px;
            display: block;
        }
    </style>
</head>
<body>
    <form id="login-form" action="login.php" method="post">
        <h2></h2>
        <input type="text" name="username" placeholder="Nombre de Usuario" required>
        <input type="password" name="password" placeholder="Contraseña" required>
        <input type="submit" value="Registrarse">
        <a href="#" class="change-password-link">Cambiar Contraseña</a>
        
    </form>

    <form id="change-password-form" action="password.php" method="post" style="display: none;">
        <h2>Cambiar Contraseña</h2>
        <input type="text" name="username" placeholder="Nombre de Usuario" required>
        <input type="password" name="old_password" placeholder="Contraseña Actual" required>
        <input type="password" name="new_password" placeholder="Nueva Contraseña" required>
        <input type="submit" value="Cambiar Contraseña">
    </form>

   

    <script>
        const loginForm = document.getElementById('login-form');
        const changePasswordForm = document.getElementById('change-password-form');
        const registerForm = document.getElementById('register-form');
        const changePasswordLink = document.querySelector('.change-password-link');
        const registerLink = document.querySelector('.register-link');

        changePasswordLink.addEventListener('click', function(e) {
            e.preventDefault();
            loginForm.style.display = 'none';
            changePasswordForm.style.display = 'block';
            registerForm.style.display = 'none';
        });

        registerLink.addEventListener('click', function(e) {
            e.preventDefault();
            loginForm.style.display = 'none';
            changePasswordForm.style.display = 'none';
            registerForm.style.display = 'block';
        });
    </script>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $servername = "localhost"; 
    $username = "root"; 
    $password = ""; 
    $database = "trabajo"; 

   
    $conn = new mysqli($servername, $username, $password, $database);

    
    if ($conn->connect_error) {
        die("Error de conexión: " . $conn->connect_error);
    }

   
    $username = $_POST['username'];
    $password = $_POST['password'];

    
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

   
    $sql = "INSERT INTO usuarios (username, password) VALUES ('$username', '$hashed_password')";

    if ($conn->query($sql) === TRUE) {
       
        header("Location: index.php");
        exit(); 
    } else {
        echo "Error al registrar usuario: " . $conn->error;
    }

    
    $conn->close();
}
?>

</body>
</html>