<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Serpiente</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            background-color: #f0f0f0;
        }

        canvas {
            border: 1px solid #000;
        }
    </style>
</head>
<body>
    <canvas id="gameCanvas" width="400" height="400"></canvas>
    <p>Puntaje: <span id="score">0</span></p>
    <button id="restartButton" style="display: none;">Reiniciar</button>

    <script>
        const canvas = document.getElementById("gameCanvas");
        const context = canvas.getContext("2d");
        const box = 20;
        let snake = [{ x: 100, y: 100 }];
        let dx = 0;
        let dy = -box; // Comienza moviendo hacia arriba
        let food = { x: 0, y: 0 };
        let score = 0;
        let gameInterval;

        function drawSnake() {
            context.clearRect(0, 0, canvas.width, canvas.height);
            snake.forEach(segment => {
                context.fillStyle = "#000";
                context.fillRect(segment.x, segment.y, box, box);
            });
        }

        function moveSnake() {
            const head = { x: snake[0].x + dx, y: snake[0].y + dy };
            snake.unshift(head);
            if (head.x === food.x && head.y === food.y) {
                generateFood();
                score += 10;
                document.getElementById("score").innerText = score;
            } else {
                snake.pop();
            }
        }

        function generateFood() {
            food.x = Math.floor(Math.random() * (canvas.width / box)) * box;
            food.y = Math.floor(Math.random() * (canvas.height / box)) * box;
        }

        function drawFood() {
            context.fillStyle = "red";
            context.fillRect(food.x, food.y, box, box);
        }

        function checkCollision() {
            const head = snake[0];
            if (
                head.x < 0 ||
                head.x >= canvas.width ||
                head.y < 0 ||
                head.y >= canvas.height ||
                snake.slice(1).some(segment => segment.x === head.x && segment.y === head.y)
            ) {
                clearInterval(gameInterval);
                alert("¡Game over!");
                document.getElementById("restartButton").style.display = "block";
            }
        }

        function update() {
            moveSnake();
            drawSnake();
            drawFood();
            checkCollision();
        }

        function restartGame() {
            // Reinicia todas las variables
            snake = [{ x: 100, y: 100 }];
            dx = 0;
            dy = -box;
            score = 0;
            document.getElementById("score").innerText = score;
            generateFood();
            // Reinicia el intervalo del juego
            gameInterval = setInterval(update, 100);
            // Oculta el botón de reinicio
            document.getElementById("restartButton").style.display = "none";
        }

        document.getElementById("restartButton").addEventListener("click", restartGame);

        document.addEventListener("keydown", event => {
            switch (event.key) {
                case "ArrowUp":
                    if (dy !== box) {
                        dx = 0;
                        dy = -box;
                    }
                    break;
                case "ArrowDown":
                    if (dy !== -box) {
                        dx = 0;
                        dy = box;
                    }
                    break;
                case "ArrowLeft":
                    if (dx !== box) {
                        dx = -box;
                        dy = 0;
                    }
                    break;
                case "ArrowRight":
                    if (dx !== -box) {
                        dx = box;
                        dy = 0;
                    }
                    break;
            }
        });

        generateFood(); 
        gameInterval = setInterval(update, 100);
    </script>
</body>
</html>

